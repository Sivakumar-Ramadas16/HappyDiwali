package com.jonnyb.rndm.Model

import java.util.*

/**
 * Created by jonnyb on 10/17/17.
 */
class Comment constructor(val username: String, val timestamp: Date, val commentTxt: String)